A Pen created at CodePen.io. You can find this one at https://codepen.io/jordyvanraaij/pen/jlAqp.

 Responstable is a CSS solution for responsive tables. It uses the HTML5 attribute <strong>data-th</strong> and the pseudo <strong>:after</strong> to create a alternate column header when in mobile view. Because it is designed mobile first you will need the respond.js (https://github.com/scottjehl/Respond) to make it work with IE8 (and below).

If you like this solution, you might also want to check out the 1.0 version:
https://gist.github.com/jordyvanraaij/9069194